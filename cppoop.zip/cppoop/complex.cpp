#include<iostream> 
using namespace std; 
class Complex 
{ 
public: 
float real; 
float img; 
Complex(float r=0, float i=0):real(r),img(i){} 
Complex operator+(const Complex& other) const; 
Complex operator-(const Complex& other) const; 
Complex operator*(const Complex& other) const; 
friend ostream& operator<<(ostream& out,const Complex& loc); 
friend istream& operator<<(istream& inp,const Complex& loc); 
}; 
Complex Complex::operator+(const Complex& other)const 
{ 
return Complex(real + other.real, img+ other.img); 
} 
Complex Complex::operator-(const Complex& other)const 
{ 
return Complex(real - other.real, img- other.img); 
} 
Complex Complex::operator*(const Complex& other)const 
{ 
return Complex(real * other.real-img* other.img, real* other.img+ img* other.real); 
} 
ostream& operator<<(ostream& out, const Complex& loc) { 
if (loc.img >= 0) 
out << loc.real << "+" << loc.img << "i"; 
else 
out << loc.real << loc.img << "i"; 
return out; 
} 
istream& operator>>(istream& inp, Complex& loc) { 
cout << "Enter real part: "; 
inp >> loc.real; 
cout << "Enter imaginary part: "; 
inp >> loc.img; 
return inp; 
} 
int main() { 
Complex c1, c2, c3; 
cout << "Enter details for complex number 1:\n"; 
cin >> c1; 
cout << "Enter details for complex number 2:\n"; 
cin >> c2; 
c3 = c1 + c2; 
cout << "Sum: " << c3 << endl; 
c3 = c1 - c2; 
cout << "Difference: " << c3 << endl; 
c3 = c1 * c2; 
cout << "Product: " << c3 << endl; 
return 0; 
}