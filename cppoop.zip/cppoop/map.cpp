#include <iostream>
 #include <map>
 #include <string>
 int main() {
    // Create a map to hold state names and populations
    std::map<std::string, int> statePopulations;
    // Add some sample states and their populations
    statePopulations["California"] = 39538223;
    statePopulations["Texas"] = 29145505;
    statePopulations["Florida"] = 21538187;
    statePopulations["New York"] = 20201249;
    statePopulations["Pennsylvania"] = 13002700;
    // Prompt the user to enter a state name
    std::string stateName;
    std::cout << "Enter the name of a state: ";
    std::getline(std::cin, stateName);
    // Search for the state in the map
    auto it = statePopulations.find(stateName);
    // Check if the state was found
    if (it != statePopulations.end()) {
        std::cout << "The population of " << stateName << " is " << it->second << ".\n";
    } else {
        std::cout << "State not found in the map.\n";
    }
    return 0;
 }