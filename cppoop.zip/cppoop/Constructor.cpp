#include <iostream> 
#include <cstring> 
 
using namespace std; 
 
class Student 
{ 
    private: 
    char* name; 
    int roll_number; 
    int student_class; 
    char division; 
    char* dob; 
    char* blood_group; 
    char* contact_address; 
    char* telephone_number; 
    char* driving_license_no; 
    static int count; 
     
    public: 
    Student() 
    { 
        name = new char[50]; 
        dob = new char[15]; 
        blood_group = new char[10]; 
        contact_address = new char[100]; 
        telephone_number = new char[15]; 
        driving_license_no = new char[20]; 
         
        strcpy(name, "Not Set"); 
        roll_number = 0; 
        student_class = 0; 
        division = 'N'; 
        strcpy(dob, "Not Set"); 
        strcpy(blood_group, "Not Set"); 
        strcpy(contact_address, "Not Set"); 
        strcpy(telephone_number, "Not Set"); 
        strcpy(driving_license_no, "Not Set"); 
         
        count++; 
    } 
 
    Student(const char* n, int roll, int cls, char div, const char* birth, const char* bg, const char* 
addr, const char* phone, const char* dl) 
{ 
        name = new char[strlen(n) + 1]; 
        dob = new char[strlen(birth) + 1]; 
        blood_group = new char[strlen(bg) + 1]; 
        contact_address = new char[strlen(addr) + 1]; 
        telephone_number = new char[strlen(phone) + 1]; 
        driving_license_no = new char[strlen(dl) + 1]; 
         
        strcpy(name, n); 
        roll_number = roll; 
        student_class = cls; 
        division = div; 
        strcpy(dob, birth); 
        strcpy(blood_group, bg); 
        strcpy(contact_address, addr); 
        strcpy(telephone_number, phone); 
        strcpy(driving_license_no, dl); 
         
        count++; 
    } 
     
    Student(const Student &s)  
    { 
        name = new char[strlen(s.name) + 1]; 
        dob = new char[strlen(s.dob) + 1]; 
        blood_group = new char[strlen(s.blood_group) + 1]; 
        contact_address = new char[strlen(s.contact_address) + 1]; 
        telephone_number = new char[strlen(s.telephone_number) + 1]; 
        driving_license_no = new char[strlen(s.driving_license_no) + 1]; 
         
        strcpy(name, s.name); 
        roll_number = s.roll_number; 
        student_class = s.student_class; 
        division = s.division; 
        strcpy(dob, s.dob); 
        strcpy(blood_group, s.blood_group); 
        strcpy(contact_address, s.contact_address); 
        strcpy(telephone_number, s.telephone_number); 
        strcpy(driving_license_no, s.driving_license_no); 
         
        count++; 
    } 
     
    ~Student() 
    { 
        delete[] name; 
        delete[] dob; 
        delete[] blood_group; 
        delete[] contact_address; 
        delete[] telephone_number; 
        delete[] driving_license_no; 
        count--; 
} 
     
    static int getCount() 
    { 
        return count; 
    } 
     
    inline void display() const 
    { 
        cout << "Name: " << name << endl; 
        cout << "Roll Number: " << roll_number << endl; 
        cout << "Class: " << student_class << endl; 
        cout << "Division: " << division << endl; 
        cout << "Date of Birth: " << dob << endl; 
        cout << "Blood Group: " << blood_group << endl; 
        cout << "Contact Address: " << contact_address << endl; 
        cout << "Telephone Number: " << telephone_number << endl; 
        cout << "Driving License No.: " << driving_license_no << endl; 
    } 
     
    friend class DisplayInfo; 
     
    void setName(const char* n) 
    { 
        strcpy(this->name, n); 
    } 
}; 
int Student::count = 0; 
 
class DisplayInfo 
{ 
    public: 
    void show(const Student &s)  
    { 
        s.display(); 
    } 
}; 
 
int main() 
{ 
 
    Student s1("John Doe", 1, 10, 'A', "01-01-2005", "O+", "123 Main St", "1234567890", 
"DL12345"); 
    Student s2("Jane Doe", 2, 10, 'B', "02-02-2006", "A+", "456 Elm St", "0987654321", 
"DL67890"); 
 
    DisplayInfo info; 
    info.show(s1); 
    cout<<"----------------------------------------------------------------------------------------\n"; 
    info.show(s2); 
 
    cout << "Total number of students: " << Student::getCount() << endl;
return 0;
}