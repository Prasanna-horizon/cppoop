 #include <iostream>
 #include <vector>
 #include <algorithm>
 #include <string>
 // Define a struct to hold personal records
 struct Person {
    std::string name;
    std::string dob;  // Date of Birth
    std::string telephone;
    // Overload the less than operator for sorting
    bool operator<(const Person &other) const {
        return name < other.name; // Sort by name by default
    }
    // Overload the equality operaAtor for searching
    bool operator==(const Person &other) const {
        return name == other.name;
    }
 };
 // Function to display a person's record
 void displayPerson(const Person &p) {
    std::cout << "Name: " << p.name << "\nDOB: " << p.dob << "\nTelephone: " << p.telephone << 
"\n\n";
 }
 int main() {
    std::vector<Person> records;
    // Adding some sample records
    records.push_back({"Alice", "1995-08-20", "123-456-7890"});
    records.push_back({"Bob", "1990-05-15", "987-654-3210"});
    records.push_back({"Charlie", "1988-12-25", "555-666-7777"});
    // Sort the records by name
    std::sort(records.begin(), records.end());
    // Display sorted records
    std::cout << "Sorted Records:\n";
    for (const auto &person : records) {
        displayPerson(person);
    }
    // Search for a specific person by name
    std::string searchName = "Bob";
    auto it = std::find_if(records.begin(), records.end(), [&](const Person &p) {
        return p.name == searchName;
    });
    if (it != records.end()) {
        std::cout << "Record found:\n";
        displayPerson(*it);
    } else {
        std::cout << "Record not found.\n";
    }
    return 0;
 }