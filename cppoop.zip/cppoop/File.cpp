#include <iostream> 
#include <fstream> 
#include <string> 
using namespace std; 
int main() { 
string filename = "example.txt"; 
// Creating and writing to the output file 
ofstream outputFile(filename); 
if (outputFile.is_open()) { 
outputFile << "This is a sample text." << endl; 
outputFile << "Here's some more text." << endl; 
outputFile.close(); 
} else { 
cerr << "Unable to open file for writing." << endl; 
return 1; 
} 
// Opening and reading from the input file 
ifstream inputFile(filename); 
if (inputFile.is_open()) { 
string line; 
while (getline(inputFile, line)) { 
cout << line << endl; 
} 
inputFile.close(); 
} else { 
cerr << "Unable to open file for reading." << endl; 
return 1; 
} 
return 0; 
}