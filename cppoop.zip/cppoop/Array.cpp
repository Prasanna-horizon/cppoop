 #include <iostream>
 using namespace std;
 // Function template for selection sort
 template <typename T>
 void selectionSort(T arr[], int size) {
    for (int i = 0; i < size - 1; ++i) {
        int minIndex = i;
        for (int j = i + 1; j < size; ++j) {
            if (arr[j] < arr[minIndex]) {
                minIndex = j;
            }
        }
        //
 //Swap the found minimum element with the first element
        if (minIndex != i) {
 T temp = arr[i];
            arr[i] = arr[minIndex];
            arr[minIndex] = temp;
        }
    }
 }
 // Function template to display the array
 template <typename T>
 void displayArray(T arr[], int size) {
    for (int i = 0; i < size; ++i) {
        cout << arr[i] << " ";
    }
    cout << endl;
 }
 int main() {
    const int intSize = 5;
    const int floatSize = 5;
    int intArray[intSize];
    float floatArray[floatSize];
    // Input integer array
    cout << "Enter 5 integers: ";
    for (int i = 0; i < intSize; ++i) {
        cin >> intArray[i];
    }
    // Input float array
    cout << "Enter 5 floats: ";
    for (int i = 0; i < floatSize; ++i) {
        cin >> floatArray[i];
    }
    // Sort and display integer array
    selectionSort(intArray, intSize);
    cout << "Sorted integer array: ";
    displayArray(intArray, intSize);
    // Sort and display float array
    selectionSort(floatArray, floatSize);
    cout << "Sorted float array: ";
    displayArray(floatArray, floatSize);
    return 0;
 }