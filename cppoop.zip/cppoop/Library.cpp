#include <iostream> 
#include <string> 
using namespace std; 
class Publication { 
protected: 
string title; 
float price; 
public: 
Publication(string t, float p) : title(t), price(p) {} 
virtual void display() const { 
cout << "Title: " << title << endl; 
cout << "Price: " << price << endl; 
} 
}; 
class Book : public Publication { 
int page_count; 
public: 
Book(string t, float p, int pc) : Publication(t, p), page_count(pc) {} 
void display() const override { 
Publication::display(); 
cout << "Page Count: " << page_count << endl; 
} 
}; 
class Tape : public Publication { 
float playing_time; 
public: 
Tape(string t, float p, float pt) : Publication(t, p), playing_time(pt) {} 
void display() const override { 
Publication::display(); 
cout << "Playing Time: " << playing_time << " minutes" << endl; 
} 
}; 
int main() { 
try { 
string title; 
float price; 
int page_count; 
float playing_time; 
cout << "Enter the title: "; 
getline(cin, title); 
cout << "Enter the price: "; 
cin >> price; 
cout << "Enter the page count: "; 
cin >> page_count; 
cout << "Enter the playing time for cassete version(in minutes): "; 
cin >> playing_time; 
Book book(title, price, page_count); 
Tape tape(title, price, playing_time); 
cout << "\nBook Details:" << endl; 
book.display(); 
cout << "\nTape Details:" << endl; 
tape.display(); 
} catch (...) { 
cout << "An error occurred, resetting all values to zero." << endl; 
Book book("0", 0.0, 0); 
Tape tape("0", 0.0, 0.0); 
cout << "\nBook Details (Reset):" << endl; 
book.display(); 
cout << "\nTape Details (Reset):" << endl; 
tape.display(); 
} 
return 0; 
}